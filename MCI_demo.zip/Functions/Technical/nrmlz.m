function hNew = nrmlz(h)
% Normalization of vector h

hNew = (h-mean(h))/max(abs(h-mean(h)));

end