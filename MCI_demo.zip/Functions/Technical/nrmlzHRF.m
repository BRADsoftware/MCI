function [sN] = nrmlzHRF(s,mn,mx)

if nargin<3
    mn = 0; 
    mx = 1;
end;

if mn>=0
    mn = 0;
end;

sN = nrmlz01(s)*(mx-mn)+mn;

end