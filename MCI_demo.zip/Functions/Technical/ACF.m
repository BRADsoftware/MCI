function [acf] = ACF(x, demonstration, mark)
% AutoCorrelation Function
% x - input signal (vector)
% demonstration = 'Y' (yes) or 'N' (no)

if nargin==1
    demonstration = 'N';
    mark = '';
end;

if nargin==2 
    mark = '';
end;

correlationFunction = @(h,k) sum((h(1:(length(h)-k))-mean(h)).*(h((k+1):length(h))-mean(h)))/sum((h-mean(h)).^2);

autocorrelation = @(h) arrayfun(@(k) correlationFunction(h,k),0:(length(h)-1));

acf = autocorrelation(x);

if strcmp(demonstration,'Y')
    plot(1:length(acf),acf,1:length(acf),zeros(size(acf)),'--');
    title(['AutoCorrelation Function ' mark]);
end;

end