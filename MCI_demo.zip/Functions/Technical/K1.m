function [k] = K1(x)
% kernel function K1 - uniform kernel
if abs(x)<=1 
    k=1/2;
else
    k=0;
end
end