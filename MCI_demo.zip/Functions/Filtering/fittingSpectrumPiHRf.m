function [vB,spB] = fittingSpectrumPiHRf(spectr0, hrf)
% Fitting the spectrum 'spectr' using the model 'sp'
% spectr - real vector, power spectrum
% sp = @(v,x) ...., where 'v' - parameters for fitting
% start - starting values for fitting 'v'
% demonstration - if 'Y' then plot the result
% type = 1 (return the same length) or 2 (return full spectrum)


% Results:
% vB - obtained parameters;
% spB - obtained estimate of spectrum.

spectr = spectr0(1:round(end/2));

x = pi/length(spectr):pi/length(spectr):pi;
x = x';

lenS = length(spectr);
H = ToeplitzMatrix(hrf,lenS);
y = zeros(1,lenS);
y(1,1) = 1;
yC = H*y';
power = abs(fft(yC)).^2;
sp = @(v,x) v(1)*power(1:lenS) + v(2);

start = [1 1];
err = @(v) trapz(x, (spectr - sp(v,x)).^2);
vB = fminsearch(err,start);
spB = sp(vB,x);


if mod(length(spectr0),2)==0
    spB = [spB; spB(end:-1:1)];
else
    spB = [spB; spB(end-1:-1:1)];
end;

end