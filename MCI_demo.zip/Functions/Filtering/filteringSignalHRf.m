function [yFiltered] = filteringSignalHRf(y,spectr,hrf,SNR)
% Wiener filter of the signal 'y' using power spectrum 'spectr'using
% signal-to-noise ration 'SNR' (if available)

if nargin<4
    nlv = noiseLevelHRf(spectr,hrf)*ones(size(spectr));
    SNR = abs((spectr-nlv)./nlv);
end;

iSNRf = ones(size(SNR))./SNR;
Yf = fft(y);
Py = abs(Yf).^2;

G1f = ones(size(Py))./(ones(size(Py)) + iSNRf);
yFiltered = real(ifft(G1f.*Yf));

end