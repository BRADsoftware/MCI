% Lasso_homotopy.m
%
% Solves
% min_x  \epsilon ||x||_1 + 1/2*||y-Ax||_2^2
%
% using only Primal update in PD_pursuit method.
%
% Here support of primal and dual vectors remain same at every step.
% The update direction here can be considered as equivalent to dual in Dantzig
% selector.

% In S-step solution property this becomes more clear when,
% if primal update direction and dual vector match at every step
% (maybe opposite in sign, depending on the formulation) then
% homotopy path taken by LASSO and Dantzig selector is exactly same.
%
% Written by: Salman Asif, Georgia Tech
% Email: sasif@ece.gatech.edu

N = 256;   % signal length
T = 30;    % sparsity level
M = 150;    % no. of measurements

% Generate a random signal
x = zeros(N,1);
q = randperm(N);
x(q(1:T)) = (randn(T,1));

% measurement matrix
A = randn(M,N)/sqrt(M); % Gaussian

% Hadamard
% H = hadamard(N);
% A = H(q(1:M),:)/sqrt(M);

% Bernoulli
% A = randsrc(M,N)/sqrt(M);

% Random Projection
% A = orth(A')';

% AtA = A'*A;

% measurements
sigma = 0.0;
e = randn(M,1)*sigma;
y = A*x+e;
thresh = 1e-5; %sqrt(2*log(N))*sigma;

% Initialization of primal and dual sign and support
z_x = zeros(N,1);
z_lambda = zeros(N,1);
gamma_lambda = [];  % Dual support
gamma_x = [];       % Primal support

% Initial step
Primal_constrk = -A'*y;
[c i] = max(abs(Primal_constrk));

gamma_lambdak = i;
gamma_xk = gamma_lambdak;

z_lambda(gamma_lambdak) = sign(Primal_constrk(gamma_lambdak));
epsilon = c;
Primal_constrk(gamma_lambdak) = sign(Primal_constrk(gamma_lambdak))*epsilon;
xk_1 = zeros(N,1);

lambdak_1 = zeros(N,1);
lambdak_1(gamma_lambdak) = inv(A(:,gamma_lambdak)'*A(:,gamma_lambdak))*z_lambda(gamma_lambdak);

Dual_constrk = A'*(A*lambdak_1);

z_x(gamma_xk) = -sign(Dual_constrk(gamma_xk));
Dual_constrk(gamma_xk) = sign(Dual_constrk(gamma_xk));

z_xk = z_x;
z_lambdak = z_lambda;

% loop parameters
done = 0;
iter = 0;
data_precision = eps;   % floating point precision

old_delta = 0;
out_lambda = [];
out_x = [];
count_delta_stop = 0;

constraint_plots = 1;

AtglAgx = A(:,gamma_lambdak)'*A(:,gamma_xk);
iAtglAgx = inv(A(:,gamma_lambdak)'*A(:,gamma_xk));
AtgxAgl = AtglAgx';
iAtgxAgl = iAtglAgx';

while ~done
    iter = iter+1;
    % warning('off','MATLAB:divideByZero')

    gamma_x = gamma_xk;
    gamma_lambda = gamma_lambdak;
    z_lambda = z_lambdak;
    z_x = z_xk;
    x_k = xk_1;
    lambda_k = lambdak_1;

    %%%%%%%%%%%%%%%%%%%%%
    %%%% update on x %%%%
    %%%%%%%%%%%%%%%%%%%%%\

    % Update direction
    %del_x = -inv(A(:,gamma_lambda)'*A(:,gamma_x))*z_lambda(gamma_lambda);
    del_x = -iAtglAgx*z_lambda(gamma_lambda);
    del_x_vec = zeros(N,1);
    del_x_vec(gamma_x) = del_x;

    pk = Primal_constrk;
    % dk = AtA*del_x_vec;
    dk = A'*(A(:,gamma_x)*del_x);

    % Compute the step size
    [i_delta, out_x, delta, chk_x] = update_primal(gamma_x, gamma_lambda, z_x,  x_k, del_x_vec, pk, dk, epsilon, out_lambda);

    if old_delta < 4*eps & delta < 4*eps
        count_delta_stop = count_delta_stop + 1;
    else
        count_delta_stop = 0;
    end
    if count_delta_stop >= 50
        disp('stuck in some corner');
        break;
    end
    old_delta = delta;

    xk_1 = x_k+delta*del_x_vec;
    Primal_constrk = pk+delta*dk;
    epsilon_old = epsilon;
    epsilon = epsilon-delta;

    if chk_x == 1
        % If an element is removed from gamma_x
        gl_old = gamma_lambda;
        gx_old = gamma_x;

        outx_index = find(gamma_x==out_x);
        gamma_x(outx_index) = gamma_x(end);
        gamma_x(end) = out_x;
        gamma_x = gamma_x(1:end-1);

        outl_index = outx_index;
        gamma_lambda = gamma_x;
        gamma_lambdak = gamma_lambda;
        gamma_xk = gamma_x;

        rowi = outx_index; % ith row of A is swapped with last row (out_x)
        colj = outl_index; % jth column of A is swapped with last column (out_lambda)
        AtgxAgl_ij = AtgxAgl;
        temp_row = AtgxAgl_ij(rowi,:);
        AtgxAgl_ij(rowi,:) = AtgxAgl_ij(end,:);
        AtgxAgl_ij(end,:) = temp_row;
        temp_col = AtgxAgl_ij(:,colj);
        AtgxAgl_ij(:,colj) = AtgxAgl_ij(:,end);
        AtgxAgl_ij(:,end) = temp_col;
        iAtgxAgl_ij = iAtgxAgl;
        temp_row = iAtgxAgl_ij(colj,:);
        iAtgxAgl_ij(colj,:) = iAtgxAgl_ij(end,:);
        iAtgxAgl_ij(end,:) = temp_row;
        temp_col = iAtgxAgl_ij(:,rowi);
        iAtgxAgl_ij(:,rowi) = iAtgxAgl_ij(:,end);
        iAtgxAgl_ij(:,end) = temp_col;

        AtgxAgl = AtgxAgl_ij(1:end-1,1:end-1);
        AtglAgx = AtgxAgl;
        iAtgxAgl = update_inverse(AtgxAgl_ij, iAtgxAgl_ij,2);
        iAtglAgx = iAtgxAgl;
        xk_1(out_x) = 0;
    else
        % If an element is added to gamma_x
        gamma_lambdak = [gamma_lambda; i_delta];
        gamma_xk = gamma_lambdak;
        i_theta = i_delta;
        new_lambda = i_delta;
        AtgxAnl = A(:,gamma_x)'*A(:,new_lambda);
        AtglAgx_mod = [AtglAgx A(:,gamma_lambda)'*A(:,i_theta); AtgxAnl' A(:,new_lambda)'*A(:,i_theta)];

        AtglAgx = AtglAgx_mod;
        AtgxAgl = AtglAgx;
        iAtglAgx = update_inverse(AtglAgx, iAtglAgx,1);
        iAtgxAgl = iAtglAgx;
        xk_1(i_theta) = 0;
    end

    z_lambdak = zeros(N,1);
    z_lambdak(gamma_lambdak) = sign(Primal_constrk(gamma_lambdak));
    z_xk = -z_lambdak;
    Primal_constrk(gamma_lambdak) = sign(Primal_constrk(gamma_lambdak))*epsilon;

    if epsilon < thresh; %sqrt(2*log(N))*sigma; %1e-7 %|| iter > 5*T || (length(gamma_lambda) == K)
        disp('epsilon break');
        break;
    end

    if iter > 500*T
        disp('too many iterations ooooooooops');
        break;
    end

    if constraint_plots
        %%
        figure(1);
        plot(pk,'.r');
        hold;
        plot(Primal_constrk);

        plot(new_lambda, Primal_constrk(new_lambda), '*k');
        legend('Old constraint', 'New constraint', 'New element','Location','Best');
        title('Shrinkage constraints');
        plot(1:N, epsilon,'k');
        plot(1:N, -epsilon, 'k');

        drawnow;
        hold off;
        pause(.1);
        %%
    end

    [iter epsilon delta]
end
[iter norm(x-xk_1)]