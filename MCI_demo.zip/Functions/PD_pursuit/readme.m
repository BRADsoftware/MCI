% compare_DASSO.m - Compares three Dantzig selector solvers:
% PD_pursuit, DASSO and l1-magic (need l1-magic to run the last function)

% Lasso_homotopy.m - it solves the Lasso homotopy by using only primal
% update phase of the primal dual pursuit.

% PD_pursuit_function.m - solves Dantzig selector for a specific value of
% epsilon using primal dual pursuit homotopy method

% PD_pursuit_test.m - tests primal dual pursuit algorithm

% readme.m

% update_dual.m - this function is used in the dual update phase to find
% the step size and changes in the primal or dual supports.

% update_primal.m - this function is used in the primal update phase to find
% the step size and changes in the primal or dual supports.

% update_inverse.m - updates the inverse of a matrix by using matrix
% inversion lemma
