function [listH1, listH2] = MVCdensities(estOLS, omega)

lenS = length(estOLS);

detGammaN = mean(omega.^2)-mean(omega)^2;
s2 = mean(omega.^2);
s1 = mean(omega);
a1 = ((1-s1)*omega+(s2-s1))/detGammaN;
a2 = (s2-s1*omega)/detGammaN;

xiE1 = mean(estOLS.*a1);
sE1 = 1/(lenS-1)*sum((a1.*(estOLS-xiE1)).^2)*lenS^(-1/5);

xiE2 = mean(estOLS.*a2);
sE2 = 1/(lenS-1)*sum((a2.*(estOLS-xiE2)).^2)*lenS^(-1/5);

sd1 = 1.06*sE1*lenS^(-1/5);
sd2 = 1.06*sE2*lenS^(-1/5);

listH1 = zeros(1,lenS);
listH2 = zeros(1,lenS);
for p = 1:lenS
    listH1(p) = max(0,estH(estOLS(p),sd1,lenS,estOLS,a1));
    listH2(p) = max(0,estH(estOLS(p),sd2,lenS,estOLS,a2));
end;

end