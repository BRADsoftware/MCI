function [omega] = PrVS(est, lambda)

%{
    Input:
        est - matrix NxK containing the set of LASSO/DS solutions in
        transition points
        lambda - corresponding vector of regularization parameters
    
    Output:
        omega - Nx1 vector of probabilities for each vector component to
        appear during the LASSO/DS solution

    Remark:
        PrVS - Probability based on Variable Selection
%}

maxK = size(est,2);
lenS = size(est,1);

if sum(abs(est(1,:))>sum(abs(est(lenS,:))))
    estT = est(:,1:end-1);
else
    estT = est(:,2:end);
end;


if maxK == 1
    ind = lambda(1);
    omega = 1;
else
    listDeltaT = lambda(1:maxK-1) - lambda(2:maxK);
    
    omega = zeros(lenS,1);
    for p = 1:lenS
        omega(p) = sum((estT(p,:)~=0).*listDeltaT)./max(lambda);
    end;
end;

end