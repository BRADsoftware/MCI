function [est0,ind,omega,listH1,listH2] = MIC_lengthSilv(est,lambda)
%{
    Using Mixture Theory  for classification peaks (activations vs noise)

Input:
    - est - NxK matrix, set of estimates for set of parameters. K
    estimates, each estimate of length N
    - lambda - 1xK vector of parameters (lambda for lasso of
    PD_pursuit)

Output:
    - ind - indexes of activations (not noise)
    - est0 - Nx1 vector, "cleaned" estimate
    - omega - Nx1 vector of probabilities (class "true activations")
    - listH1,listH2 - Nx1 vectors of values of densities f1,f2 for OLS vector (1 - "true
    activations", 2 - "noise")

%}

lenS = size(est,1);
maxK = size(est,2);

if sum(abs(est(1,:))>sum(abs(est(lenS,:))))
    estT = est(:,1:end-1);
else
    estT = est(:,2:end);
end;



if sum(abs(est(:,1))>sum(abs(est(:,end))))
    estOLS = est(:,1);
else
    estOLS = est(:,end);
end;

if maxK == 1
    ind = lambda(1);
    omega = 1;
else
    listDeltaT = lambda(1:maxK-1) - lambda(2:maxK);
    
    omega = zeros(lenS,1);
    for p = 1:lenS
        omega(p) = sum((estT(p,:)~=0).*listDeltaT)./max(lambda);
    end;

    detGammaN = mean(omega.^2)-mean(omega)^2;
    s2 = mean(omega.^2);
    s1 = mean(omega);
    a1 = ((1-s1)*omega+(s2-s1))/detGammaN;
    a2 = (s2-s1*omega)/detGammaN;

    xiE1 = mean(estOLS.*a1);
    sE1 = 1/(lenS-1)*sum((a1.*(estOLS-xiE1)).^2)*lenS^(-1/5);

    xiE2 = mean(estOLS.*a2);
    sE2 = 1/(lenS-1)*sum((a2.*(estOLS-xiE2)).^2)*lenS^(-1/5);

    sd1 = 1.06*sE1*lenS^(-1/5);
    sd2 = 1.06*sE2*lenS^(-1/5);

    listH1 = zeros(1,lenS);
    listH2 = zeros(1,lenS);
    for p = 1:lenS
        listH1(p) = max(0,estH(estOLS(p),sd1,lenS,estOLS,a1));
        listH2(p) = max(0,estH(estOLS(p),sd2,lenS,estOLS,a2));
    end;
    
    ind = find(omega.*listH1'>(1-omega).*listH2');
end;
    
est0 = zeros(lenS,1);
est0(ind) = 1;
est0 = est0.*estOLS;


end
