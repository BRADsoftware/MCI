function [estDSset, lambdaset] = decDSset(output, H1, parameter)
% (Collection of estimates)
% Find the Dantzig Selector estimate for the signal 'output'
% 'output' = 1D-vector! 

if nargin<3
    parameter = usualParameters;
end

if isfield(parameter,'stopEarlier')
    stopEarlier = parameter.stopEarlier;
else 
    stopEarlier = 0;
end

[lambdaset, ~, estDSset] = ...
    PD_pursuit_function_listSupp(H1, H1'*H1, output, parameter.accurancy,...
    parameter.maxIteration,stopEarlier);
    
end