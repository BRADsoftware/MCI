function [currentEstimate] = abIC(estimatesSet,M)
%{
    Selection of the estimate number M from matrix estimatesSet

Input:
     - estimatesSet - NxK matrix containing K estimates of length N
     - M - number from 1 to K, corresponds to needed number of estimate in
     estimatesSet matrix

Output:
    - currentEstimate - chosen estimate from estimateSet matrix

%}

    currentEstimate = estimatesSet(:,M);

end