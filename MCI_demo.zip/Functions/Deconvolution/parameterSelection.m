function [bestindex] = parameterSelection(y,estimates,H,criteria)
%{
 Selection Criteria: BIC or AIC
BIC: 
    optimalIndex = arg min [ N*log(||y-H*s(index)||_2^2) + log(N)*df(index)]
AIC: 
    optimalIndex = arg min [ N*log(||y-H*s(index)||_2^2) + 2*df(index)]
Here df is degrees of freedoms, its estimate is: df(index) = #{j: s(index,j) ~= 0}
 (number of nonzero elements in the solution, corresponding to particula index)


Input:
y - Nx1 vector-column, original signal to be deconvolved
estimates - NxK matrix, containing K estimates of deconvolved y
H - convolution (Toeplitz) matrix, NxN
criteria - 'BIC','AIC','AICc'
%}

if nargin<4
    criteria = 'BIC';
end;

N = length(y);
maxK = size(estimates,2);

% AIC or BIC
if strcmp(criteria,'BIC')
    wn = log(N);
else 
    wn = 2;
end;


yEst = zeros(size(estimates));
df = zeros(1,maxK);
res = zeros(1,maxK);
dfc = zeros(1,maxK);
for k=1:maxK
    yEst(:,k) = H*estimates(:,k);
    df(k) = nnz(estimates(:,k));
    dfc(k) = 2*df(k)*(df(k)+1)/(length(y)-df(k)-1);
    res(k) = log(norm(y - yEst(:,k))^2);
end;

crit = N*res + wn*df;
if strcmp(criteria,'AICc')
    crit = N*res + wn*df + dfc;
end;
bestindex = find(crit==min(crit));
bestindex = bestindex(1);

end