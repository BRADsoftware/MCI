function [est0] = BayesClassifier(estOLS, omega, listH1, listH2)
%{
    Using Mixture Theory  for classification peaks (activations vs noise)

Input:
    - estOLS - OLS-estimate, vector of the length N
    - omega - probabilities to belong to class 1 (activations)
    
Output:
    - ind - indexes of activations (not noise)
    - est0 - Nx1 vector, "cleaned" estimate

%}

lenS = size(omega,1);

      
ind = (omega.*listH1'>(1-omega).*listH2');
    
est0 = zeros(lenS,1);
est0(ind) = 1;
est0 = est0.*estOLS;


end
