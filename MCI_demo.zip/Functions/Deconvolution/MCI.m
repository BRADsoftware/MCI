function sbjDeconv = MCI(sbj,hrf)

% Mixture Component Inference deconvolution
% Input:
%   - sbj - NxK matrix of BOLD signals. N time points, K time series
%   - hrf - hemodynamic response function, Lx1 vector, L<N.
%
% Output:
%   - sbjDeconv - NxK matrix with deconvolved signal


lenS = size(sbj,1);
H = ToeplitzMatrix(hrf,lenS);

for iSbj = 1:size(sbj,2)
    
    % rescale BOLD to [0,1]
    y = nrmlz01(sbj(:,iSbj));

    % run PD-pursuit (or LARS)
    [estSet,lmbd] = decDSset(y,H); % or decLASSOset(y,H) for LARS

    % MCI
    xi = estSet(:,end); % xi - here OLS solution
    [omega] = PrVS(estSet, lmbd); % probabilities, based on DS set of solutions
    [listH1, listH2] = MVCdensities(xi, omega); % f1(xi) and f2(xi)
    sbjDeconv(:,iSbj) = BayesClassifier(xi, omega, listH1, listH2);

end

end





