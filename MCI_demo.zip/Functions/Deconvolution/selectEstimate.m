function [currentEstimate] = selectEstimate(estimatesSet, SC, information)
%{
    Selecting one estimate from the set of estimates.
Imput:
    - estimatesSet - NxK matrix, set of K estimates of length N
    - SC - selection criteria, 'AIC'/'BIC'/'MT'/'KPA'
    (KPA - Known Peaks Amount, MT - Mixture Theory)
    - information - additional information, corresponding to SC
    ( number from 1 to K for AIC and BIC - index of the estimate in the
    matrix 'estimatesSet',
      1xK matrix of parameters lambda for MT(Mixture Theory)
      number from 1 to N for KPA - how many peaks to choose )

Output: 
    - Nx1 numerical vector, corresponds to chosed estimate
%}

switch SC
case 'AIC'
    currentEstimate = abIC(estimatesSet,information);   % here 'information' is best index according to AIC
case 'AICc'
    currentEstimate = abIC(estimatesSet,information);   % here 'information' is best index according to AIC
case 'BIC'
    currentEstimate = abIC(estimatesSet,information);   % here 'information' is best index according to BIC
case 'MT'
    currentEstimate = MIC_lengthSilv(estimatesSet,information); % here 'information' is 'lambda'
case 'KPA'
    currentEstimate = knownPeaksAmount(estimatesSet,information); % here 'information' is 'known peaks amount'
case 'AllP'
    currentEstimate = knownPeaksAmount(estimatesSet, information); % here 'information' is 'all peaks'
end;

end