clearvars

sbj = load('checkerboard.csv');
TR = 2.5;

hrf = spm_hrf(TR);

sbjDeconv = MCI(sbj,hrf);

figure('pos',[10 10 1200 400]); 
plot(nrmlz01(sbj),'b');
hold on;
plot(sbjDeconv,'r');
title('Example of MCI deconvolution');
legend('BOLD','Deconvolved signal');




